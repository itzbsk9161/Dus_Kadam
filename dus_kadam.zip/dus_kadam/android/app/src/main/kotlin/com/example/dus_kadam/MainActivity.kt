package com.example.dus_kadam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
