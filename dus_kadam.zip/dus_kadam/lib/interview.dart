// Why are you applying for this job?
//    I have applied for this vacancy because it is an excellent match for my skills
//    and experience. This role is exactly the sort of role I am currently targeting,
//    and I am confident I will be able to make a major contribution.

// Why should we hire you?
//I believe that everyone starts with a beginning, I need a platform to prove my abilities
// and skills. I think your company is the right place to explore my abilities. I need to
// be a part of your growth. I will do my level best.

//What are your salary expectations?
// Learning and gaining experience is my major priority. As your company is one of
// the most reputed company, I just accept the salary offered by you is the best in
// the industry.

//Assume you are hired, then how long would you expect to work for us?
//"I will do my best for the growth of your company as long as I have the career growth,
// job satisfaction, respect and a healthy environment, then I don't need to change
// my company."

//What are your achievements in life?
//"My biggest accomplishment is overcoming my fear of failure.
// It gives me a complete sense of living and makes me more confident."

//What are your strengths?
//My main strengths are the ability to use my initiative to take on challenges.
// I am always proactive at what I do, and that keeps my mind stimulated and focused

//What are your weaknesses?
//"I am a straightforward person, and I cannot say no when someone asks me for help.0